AUTO KEY CLICKER
================

The Auto Key Clicker is a small applet that I wrote when I was bored, which presses the specified key at the specified rate. It supports almost all the keys on a standard keyboard (well mine anyway), and can run at speeds up to 1 click per millisecond.

HOW-TO
======

The program defaults to the Left Mouse button, at a speed of one click per second. On use, to change these, just type the required key into the key pressed: box, and click Set Key. You can change the interval by setting the desired interval in the box and clicking the Set Interval button. You can also toggle confirmation alerts with a checkbox in the bottom right. To begin the clicking, just click Start, or hit F3. To stop it, click Stop, or hit F4. To see supported keys, just click the Key Codes menu option to see all supported keycodes.


UPDATE HISTORY
==============

Version 1.2
Fixed changing of Start/stophotkeys
Allowed input of multiple keys
Optimized code for faster key input
Added saving to keep your settings on next startup. Program saves into AppData\local\lolStudios\AutoKeyClicker folder

Version 1.1
Enabled changing of Start/Stop hotkeys.

Version: 1.0.3
Support for the shift-ed versions of most keys. Checkbox added for those who prefer confirmation of a successful key or interval change.

Version 1.0.2
Fixed the Start and stop function keys not working if the program wasn't in focus

Version 1.0.1:
Bug fixed where the Mouse Left and Mouse Right options would return a wrong key error.

Version 1.0:
First iteration of the program. Interface designed, and code written. 